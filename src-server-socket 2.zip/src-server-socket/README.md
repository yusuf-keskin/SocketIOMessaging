install nodeJs
run terminal in this window and end enter  
    node index.js
    
then server will start in local
